
# Info

This mod allows you to place markers on your map.


## Controls

Left Click ( No drag ) : Place Marker
Right click : Remove Marker
Interact ( Default E ) : Cycle through colours
Scroll Wheel : Change marker size ( also zooms on map, zoom in for smaller marker, zoom out for larger marker )

## Installation (manual)

If you are installing this manually, do the following

1. Extract the archive into a folder. **Do not extract into the game folder.**
2. Move the contents of `plugins` folder into `<GameDirectory>\Bepinex\plugins`.
3. Run the game.
