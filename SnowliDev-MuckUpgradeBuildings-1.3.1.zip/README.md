[This video](https://youtu.be/ivm0xB6vF44) shows how I made this mod, showcases the features and has a tutorial on how to install this mod automatically or manually (with timestamps in the description).
If you have any trouble installing the mod or have feedback/find bugs, feel free to [join my Discord](https://discord.gg/uQn974CjjC)

# UpgradeBuildings for Muck
This mod adds a hammer to upgrade, repair and instantly break buildings with resources.
You can upgrade building structures (walls, stairs, etc.) for more hp using wood.
Furnaces and Cauldrons can be upgraded with metals to increase process speed, efficiency (how much you get) and fuel efficiency.

## Changelog
- fixed minor bugs, added links to README
- fixed bugs with the hammer
- added upgrades for furnaces and cauldrons
- changed wall upgrades to Wood (Wood, Birch, Fir, Oak, Dark Oak)
- Added hammer
- Added multiplayer
- added upgradable building structures.

## Installation
This mod requires BepInEx.

Extract the files and place the entire **MuckUpgradeBuildings** folder in the BepInEx plugin folder.

You can also install it automatically using the Thunderstore Mod Manager or r2modman (recommended).

## Usage in game
Craft the **Build Hammer** using **5 Wood** in the **Workbench**.

This hammer can then be used on all placable build structures.

**Left click** (hit) to repair the structure using *1 resource* (e.g. 1 Wood)
**Hold right click** to open the upgrade menu
1. upgrade to the next level for 2 resources (e.g. 2 Birch Wood)
2. repair the structure for 1 resource
3. instantly destroy the structure (same as hitting it until it breaks)

**release right click to choose the option**

## Structure levels
- Wood
- Birch Wood
- Fir Wood
- Oak Wood
- Dark Oak Wood

## Furnace / Cauldron levels
- Stone
- Iron
- Mithril
- Adamantite
- Obamium

## Multiplayer
This mod now also works in multiplayer! Everyone can upgrade, repair and destroy everything.

## For developers
You can add your own upgrade levels!
Just include this dll as dependency and call the UpgradableBuild/UpgradableFurnace/UpgradableCauldron.addLevel function in the Awake function of your plugin. 
Make sure to also add this plugin as BepInDependency (dev.snowli.plugins.muckupgradebuildings).

## Images
![Different wood structures](https://imgur.com/MzigJxP.jpg)
![Different furnace levels](https://imgur.com/Hb6GcvH.jpg)
![Different cauldron levels](https://imgur.com/pRaXr7M.jpg) 