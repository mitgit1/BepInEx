---Death Counter---
1.0.0
This mod adds a death counter text in the main menu. (Starts at 0, of course)

#How to install:
 --- Unzip delusional-DeathCounter-Muck.zip
 --- Go to Muck folder (if you don't know how to do it, read the last pharagraph).
 --- Copy "DeadCounter.dll" file into the next directory:
\BepInEx\plugins

If you don't have BepInEx already, you can download it here:
https://muck.thunderstore.io/package/BepInEx/BepInExPack_Muck/

If you don't know how to reach Muck's folder:
Go to Steam Library >>
Right-click on Muck >>
Go to Properties >>
Go to Local Files >>
Press Explore.