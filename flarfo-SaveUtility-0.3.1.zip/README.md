**Release v0.3.1**
(PRE 0.3.0 SAVE FILES ARE NO LONGER COMPATIBLE WITH NEWEST RELEASE)

*A brand new mod for Muck that allows players to save their games!*

### What does it do?

SaveUtility currently supports saving:

- Inventory
- Player Status
- Powerups
- Time
- Chests/Furnaces/Cauldrons
- Builds
- Bosses
- World Seed
- Boat Status
- Recipes
- Dropped Items
- Multiplayer Data*

*ALL PLAYERS MUST HAVE THE MOD INSTALLED FOR MULTIPLAYER TO WORK!

All to a custom save file located at:

**C:\Program Files (x86)\Steam\steamapps\common\Muck\Saves**

### How do I use it?

You can manually save your worlds by opening the pause menu and selecting the **Save** button. This button has a 60 second cooldown. A save file is generated with the world seed as its name. You can rename the worlds from the **Saves** folder at a later time.

SaveUtility will also automatically save your worlds at the start of every new day if you have **Auto Save** enabled in Gameplay Settings.

The mod adds a custom GUI to allow users to easily select and load any save from the folder.

Before you start a game, you can select the **Load Save** button to access the GUI and select a save from your saves folder. By clicking and dragging on the list, you can scroll through a list of all of your saves.

If you **right click** on any of the save buttons in the GUI, a menu will pop up. By selecting "Delete" you can delete that world save from your game.

It's that simple!

## Changelog
## v0.1.0 *Alpha Release 1*
- Added Inventory Saving
- Added Player Status Saving
- Added Powerup Saving
- Added Chest Saving
- Added Seed Saving
- Added Mob Saving

## v0.1.1 *Updated Page*
- I can't spell

## v0.2.0 *Alpha Release 2*
- Save Button in Pause Menu 
- Boat Saving 
- Recipe Saving 
- Fixed Issues with Mobs 
- Fixed Issues with Dracula Max HP

## v0.3.0 *Alpha Release 3* 
- Added Multiplayer Support 
- Added Dropped Item Saving 
- Added Furnace/Cauldron Saving
- Converted To XML Serialization 
- Removed Normal Mob Saving, Replaced with Bosses Only 
- Massively Improved GUI - Fixed Recipe Saving 
- Fixed Issue with Saving While Dead
- Fixed Chests Being Spawned at Slightly Offset Positions

## v0.3.1 *Release 4*
- Updated references
- Added nothing